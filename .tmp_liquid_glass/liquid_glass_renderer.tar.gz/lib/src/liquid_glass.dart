// ignore_for_file: avoid_setters_without_getters

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:liquid_glass_renderer/liquid_glass_renderer.dart';
import 'package:liquid_glass_renderer/src/internal/transform_tracking_repaint_boundary_mixin.dart';
import 'package:liquid_glass_renderer/src/liquid_glass_blend_group.dart';
import 'package:liquid_glass_renderer/src/liquid_glass_render_scope.dart';
import 'package:meta/meta.dart';

/// A liquid glass shape.
///
/// To render liquid glass, you probably want to wrap this in a
/// [LiquidGlassLayer], where the glass effect will be rendered.
///
/// This can either create a single shape, or be blended together with other
/// shapes in a parent [LiquidGlassBlendGroup] by using the
/// [LiquidGlass.grouped] constructor.
///
/// If you only need a single shape with its own settings, you can also use the
/// [LiquidGlass.withOwnLayer] constructor, which will create its own
/// [LiquidGlassLayer] internally.
/// Be mindful that creating many individual layers can be expensive.
///
/// See the [LiquidGlassLayer] documentation for more information.
class LiquidGlass extends StatelessWidget {
  /// Creates a new [LiquidGlass] with the given [child] and [shape].
  ///
  /// This will expect a parent [LiquidGlassLayer] to be present in the widget
  /// tree, where the liquid glass effect will be rendered.
  const LiquidGlass({
    required this.child,
    required this.shape,
    this.glassContainsChild = false,
    this.clipBehavior = Clip.hardEdge,
    super.key,
  })  : grouped = false,
        blendGroupLink = null,
        ownLayerConfig = null;

  /// Creates a new [LiquidGlass] that is part of a [LiquidGlassBlendGroup].
  ///
  /// This will expect a parent [LiquidGlassBlendGroup] to be present in the
  /// widget tree, as well as a parent [LiquidGlassLayer] above that, where the
  /// result will be rendered.
  const LiquidGlass.grouped({
    required this.child,
    required this.shape,
    super.key,
    this.glassContainsChild = false,
    this.clipBehavior = Clip.hardEdge,
    this.blendGroupLink,
  })  : ownLayerConfig = null,
        grouped = true;

  /// Creates a new [LiquidGlass] that creates its own [LiquidGlassLayer].
  ///
  /// While this might seem convenient, creating many individual layers can be
  /// expensive.
  ///
  /// You should prefer rendering multiple [LiquidGlass] shapes that share the
  /// same settings inside a single [LiquidGlassLayer] for better performance.
  const LiquidGlass.withOwnLayer({
    required this.child,
    required this.shape,
    LiquidGlassSettings settings = const LiquidGlassSettings(),
    bool fake = false,
    super.key,
    this.glassContainsChild = false,
    this.clipBehavior = Clip.hardEdge,
    this.blendGroupLink,
  })  : ownLayerConfig = (settings, fake),
        grouped = false;

  /// The child of this widget.
  ///
  /// You can choose whether this should be rendered "inside" of the glass, or
  /// on top using [glassContainsChild].
  final Widget child;

  /// {@template liquid_glass_renderer.LiquidGlass.shape}
  /// The shape of this glass.
  ///
  /// This is the shape of the glass that will be rendered.
  /// {@endtemplate}
  final LiquidShape shape;

  /// Whether this glass should be rendered "inside" of the glass, or on top.
  ///
  /// If it is rendered inside, the color tint
  /// of the glass will affect the child, and it will also be refracted.
  ///
  /// Defaults to `false`.
  final bool glassContainsChild;

  /// The clip behavior of this glass.
  ///
  /// Defaults to [Clip.none], so [child] will not be clipped.
  final Clip clipBehavior;

  /// Whether this glass is part of a blend group.
  final bool grouped;

  /// The link to this glass's blend group if it is part of one.
  final GlassGroupLink? blendGroupLink;

  /// The settings for this glass if it is supposed to create its own layer.
  final (LiquidGlassSettings settings, bool fake)? ownLayerConfig;

  @override
  Widget build(BuildContext context) {
    // If we have our own layer config, we create our own layer.
    if (ownLayerConfig case (final settings, final fake)) {
      if (fake) {
        return FakeGlass(
          shape: shape,
          settings: settings,
          child: child,
        );
      }

      return LiquidGlassLayer(
        settings: settings,
        child: LiquidGlassBlendGroup(
          blend: 0,
          child: Builder(
            builder: _buildContent,
          ),
        ),
      );
    }

    final fake = LiquidGlassRenderScope.of(context).useFake;

    if (fake) {
      return FakeGlass.inLayer(
        shape: shape,
        child: child,
      );
    }

    final blendGroupLink = grouped
        ? this.blendGroupLink ?? LiquidGlassBlendGroup.maybeOf(context)
        : null;

    if (blendGroupLink == null) {
      // For now we create our own blend group until we support non-blended
      // geometry generation
      return LiquidGlassBlendGroup(
        blend: 0,
        child: Builder(
          builder: (context) => _buildContent(
            context,
            LiquidGlassBlendGroup.of(context),
          ),
        ),
      );
    }

    return _buildContent(
      context,
      blendGroupLink,
    );
  }

  Widget _buildContent(BuildContext context, [GlassGroupLink? blendGroupLink]) {
    final settings = LiquidGlassSettings.of(context);

    if (!ImageFilter.isShaderFilterSupported) {
      return FakeGlass.inLayer(
        shape: shape,
        child: child,
      );
    }

    return _RawLiquidGlass(
      blendGroupLink: blendGroupLink ?? LiquidGlassBlendGroup.of(context),
      shape: shape,
      glassContainsChild: glassContainsChild,
      child: ClipPath(
        clipper: ShapeBorderClipper(shape: shape),
        clipBehavior: clipBehavior,
        child: Opacity(
          opacity: settings.visibility.clamp(0, 1),
          child: GlassGlowLayer(
            child: child,
          ),
        ),
      ),
    );
  }
}

class _RawLiquidGlass extends SingleChildRenderObjectWidget {
  const _RawLiquidGlass({
    required super.child,
    required this.shape,
    required this.glassContainsChild,
    required this.blendGroupLink,
  });

  final LiquidShape shape;

  final bool glassContainsChild;

  final GlassGroupLink? blendGroupLink;

  @override
  RenderObject createRenderObject(BuildContext context) {
    return RenderLiquidGlass(
      shape: shape,
      glassContainsChild: glassContainsChild,
      blendGroupLink: blendGroupLink,
    );
  }

  @override
  void updateRenderObject(
    BuildContext context,
    RenderLiquidGlass renderObject,
  ) {
    renderObject
      ..shape = shape
      ..glassContainsChild = glassContainsChild
      ..blendGroupLink = blendGroupLink;
  }
}

@internal
class RenderLiquidGlass extends RenderProxyBox
    with TransformTrackingRenderObjectMixin {
  RenderLiquidGlass({
    required LiquidShape shape,
    required bool glassContainsChild,
    required GlassGroupLink? blendGroupLink,
  })  : _shape = shape,
        _glassContainsChild = glassContainsChild,
        _blendGroupLink = blendGroupLink;

  late LiquidShape _shape;
  LiquidShape get shape => _shape;
  set shape(LiquidShape value) {
    if (_shape == value) return;
    _shape = value;
    markNeedsPaint();
    _updateBlendGroupLink();
  }

  bool _glassContainsChild = true;
  bool get glassContainsChild => _glassContainsChild;
  set glassContainsChild(bool value) {
    if (_glassContainsChild == value) return;
    _glassContainsChild = value;
    _updateBlendGroupLink();
  }

  GlassGroupLink? _blendGroupLink;
  set blendGroupLink(GlassGroupLink? value) {
    if (_blendGroupLink == value) return;
    _unregisterFromParentLayer();
    _blendGroupLink = value;
    _registerWithLink();
  }

  final transformLayerHandle = LayerHandle<TransformLayer>();

  @override
  void attach(PipelineOwner owner) {
    super.attach(owner);
    _registerWithLink();
  }

  @override
  void detach() {
    _unregisterFromParentLayer();
    transformLayerHandle.layer = null;
    super.detach();
  }

  void _registerWithLink() {
    if (_blendGroupLink != null) {
      _blendGroupLink!.registerShape(
        this,
        _shape,
        glassContainsChild: _glassContainsChild,
      );
    }
  }

  void _unregisterFromParentLayer() {
    _blendGroupLink?.unregisterShape(this);
  }

  void _updateBlendGroupLink() {
    _blendGroupLink?.updateShape(
      this,
      _shape,
      glassContainsChild: _glassContainsChild,
    );
  }

  late Path _lastPath;

  @override
  void performLayout() {
    super.performLayout();
    // Notify parent layer when our layout changes
    _lastPath = shape.getOuterPath(Offset.zero & size);
    _blendGroupLink?.notifyShapeLayoutChanged(this);
  }

  @override
  void onTransformChanged() {
    _blendGroupLink?.notifyShapeLayoutChanged(this);
  }

  @override
  // ignore: must_call_super
  void paint(PaintingContext context, Offset offset) {
    setUpLayer(offset);
  }

  void paintFromLayer(
    PaintingContext context,
    Matrix4 transform,
    Offset offset,
  ) {
    if (attached) {
      transformLayerHandle.layer = context.pushTransform(
        needsCompositing,
        offset,
        transform,
        super.paint,
        oldLayer: transformLayerHandle.layer,
      );
    }
  }

  Path getPath() {
    return _lastPath;
  }
}
